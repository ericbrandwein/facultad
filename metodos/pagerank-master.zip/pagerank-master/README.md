A continuación se enumeran los distintos archivos y carpetas
del proyecto y sus contenidos.

- `informe/informe.pdf`: El informe realizado.
- `include/`, `src/`: Los archivos fuente del algoritmo
implementado.
- `experimentacion/`: Los scripts de generación de grafos
para la experimentación.
- `grafos-entrada/`: Los grafos de entrada usados para hacer
experimentación sobre el algoritmo.
- `tests/`: Tests provistos por la cátedra, y scripts en R
misceláneos.
- `tests/resultados/`: Resultados de experimentaciones.
- `graficos/`: Los gráficos de experimentación en formato `.png`,
y los scripts en R usados para generarlos a partir de los datos.
- `medir_error.cpp`: Archivo fuente de programa utilizado para
medir el error de los resultados del algoritmo implementado.

## Para compilar:

    make tp1

## Para correr:

    ./build/tp1 <archivo> <p>

### Si se quiere guardar en un archivo 'archivo.out':

    ./build/tp1 <archivo> <p> > archivo.out

### Ejemplos:

    ./build/tp1 tests/data/test-aleatorio-desordenado.txt 0.76
    ./build/tp1 grafos-entrada/estrella-1-a-5.txt 0.8 > archivo.out


