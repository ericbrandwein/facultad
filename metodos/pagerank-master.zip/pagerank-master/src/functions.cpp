#include "matrix.hpp"
#include "operators.hpp"

matrix
random_matrix(int numrows, int numcols, double low, double high, double epsilon) {
    static std::default_random_engine re;
    std::uniform_real_distribution<double> unif(low, high);

    std::vector<double> v{};
    for (int i = 0; i < numrows * numcols; i++)
        v.push_back(unif(re));

    return matrix{epsilon, v, numrows};
}

matrix transpose(matrix &m) {
    matrix res{m.GetEpsilon(), m.numcols(), m.numrows()};
    for (int r = 0; r < m.numrows(); r++)
        for (int c = 0; c < m.numcols(); c++)
            res[c].set(r, m[r].get(c));
    return res;
}


//le sumo k veces la fila i a la fila j
void sum_row_i_times_k_to_row_j(matrix &m, int& row_i, double& k, int& row_j, int& desde_que_columna){

    // m[row_j].set(desde_que_columna, 0);
    // for(int indice = desde_que_columna+1; indice<m.numcols(); indice++){
    //     m[row_j].add(indice, k*m[row_i].get(indice));
    // }

    for(auto itero_fila = m[row_i].begin_in_map(); itero_fila.is_not_map_end(); itero_fila=itero_fila.next_in_map()){
        int indice = itero_fila.getIndex();
        m[row_j].add( indice, k*m[row_i].get( indice ) );
    }

}

matrix gaussian_elimination(matrix &m){

    //para cada fila ..
    for(int row = 0; row<m.numrows(); row++){

        //si m[row][row] es 0 swapearla con otra que no tenga 0 en m[row'][row]
        // si todas son 0.. continue
        bool son_todos_ceros = true;
        int nuevo_row;
        if( fabs(m[row].get(row)) < m.GetEpsilon() ) {
            for (int row_new = row + 1; row_new < m.numrows(); row_new++) {
                if (fabs(m[row_new].get(row)) > m.GetEpsilon()) {
                    son_todos_ceros = false;
                    nuevo_row = row_new;
                    break;
                }
            }
            if (son_todos_ceros)
                continue;
            else
                std::swap(m[row], m[nuevo_row]);
        }

        //hago 0 todos los de abajo
        for(int row_prima = row+1; row_prima<m.numrows(); row_prima++){
            if( fabs(m[row_prima].get(row)) > m.GetEpsilon() ){
                double k = -m[row_prima].get(row) / m[row].get(row);
                sum_row_i_times_k_to_row_j( m, row, k, row_prima, row );
            }
        }
    }

    return m;
}


matrix gaussian_elimination_sin_pivoteo(matrix &m){

    std::set<int> elegidos;

    //para cada fila ..
    for(int row = 0; row<m.numrows(); row++){
        //busco un j en m[j][row] que no sea 0
        int j = -1;
        for(int i=0; i<m.numrows(); i++)
            if( fabs(m[i].get(row)) > m.GetEpsilon() && elegidos.find(i)==elegidos.end() ){
                j = i;
                elegidos.insert(i);
                break;
            }
        if( j == -1 )
            continue;

        //hago 0 todos los != j
        for(int row_prima = 0; row_prima<m.numrows(); row_prima++){
            if( row_prima == j ) continue;

            if( fabs(m[row_prima].get(j)) > m.GetEpsilon() ){
                double k = -m[row_prima].get(j) / m[j].get(j);
                sum_row_i_times_k_to_row_j( m, j, k, row_prima, row );
            }
        }

    }

    return m;
}

inline bool is_zero(double num) {
    return fabs(num) <= EPSILON;
}

// Resuelve ecuaciones de la pinta Ax=t
// devuelve el vector x_1, x_2, .., x_n normalizado
std::vector<double> solve(matrix &m, std::vector<double> &t){

    // std::set<int> elegidos;
    // std::vector<int> indices_orden;

    // //para cada fila ..
    // for (int col_actual = 0; col_actual<m.numrows(); col_actual++) {
    //     //quiero un row_actual en m[row_actual][col_actual] que no sea 0
    //     int row_actual = -1;
    //     int i = 0;
    //     for (; i < m.numrows() && (
    //             is_zero(m[i].get(col_actual)) ||
    //                 elegidos.find(i) != elegidos.end()
    //         ); i++);

    //     if (i != m.numrows()) {
    //         // de los que no elegi, busco el primero que no sea 0
    //         row_actual = i;
    //         elegidos.insert(i);
    //         indices_orden.push_back(i);
    //     } else {
    //         // no deberia llegar aca
    //         continue;
    //     }

    //     // hago 0 todos los !=(row_actual)  (esto tarda mucho!!!)
    //     double divido = m[row_actual].get(col_actual);
    //     for (int row_prima = 0; row_prima < m.numrows(); row_prima++) {
    //         double valor = m[row_prima].get(col_actual);
    //         if (row_prima != row_actual && !is_zero(valor) //sabemos que fabs(m[j].get(j)) > EPSILON, no hubiera elegido ese j sino
    //             /*&& fabs(m[j].get(j)) > EPSILON*/ ) {
    //             double cociente = -valor / divido;
    //             sum_row_i_times_k_to_row_j(
    //                 m, row_actual, cociente, row_prima, col_actual);
    //             t[row_prima] += cociente * t[row_actual];
    //         }
    //     }
    // }


    // std::vector<double> resultado(indices_orden.size());
    // double suma_total = 0;
    // //obtengo x_1, ..., x_n
    // for(unsigned int i = 0; i<indices_orden.size(); i++){
    //     double value = t[ indices_orden[i] ]/m[ indices_orden[i] ].get(i);
    //     resultado[ i ] = value;
    //     suma_total += value;
    // }
    // //normalizo
    // for(unsigned int i = 0; i<resultado.size(); i++)
    //     resultado[i] = resultado[i]/suma_total;

    // return resultado;
    //--------------------------------------------------------------
    
    for(int row_actual = 0; row_actual<m.numrows(); row_actual++){

        // hago 0 todos los !=(row_actual)
        double divido = m[row_actual].get(row_actual);
        for(int row_prima = 0; row_prima<m.numrows(); row_prima++){

            if( row_prima == row_actual ) continue;
            double valor = m[row_prima].get(row_actual);
            if( fabs( valor ) > m.GetEpsilon() ){
                double cociente = - valor / divido;
                sum_row_i_times_k_to_row_j( m, row_actual, cociente, row_prima, row_actual );
                t[row_prima] += cociente*t[row_actual];
            }
        }
    }


    std::vector<double > resultado(m.numrows());
    double suma_total = 0;
    //obtengo x_1, ..., x_n
    for(unsigned int i = 0; i < static_cast<unsigned>(m.numrows()); i++){
        double value = t[ i ]/m[ i ].get(i);
        resultado[ i ] = value;
        suma_total += value;
    }
    //normalizo
    for(unsigned int i = 0; i<resultado.size(); i++)
        resultado[i] = resultado[i]/suma_total;

    return resultado;

}
