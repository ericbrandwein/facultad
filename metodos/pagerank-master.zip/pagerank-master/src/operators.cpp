#include "matrix.hpp"



std::vector<double>
operator*(double d, const std::vector<double>& v) {
    std::vector<double>res{v};
    for (auto& x : res)
        x *= d;
    return res;
}

std::vector<double>
operator/(std::vector<double>& v,double d) {
    std::vector<double>res{v};
    for (auto& x : res)
        x /= d;
    return res;
}


matrix operator+(matrix a, const matrix& b) {
    a += b;
    return a;
}

matrix operator*(double scalar, matrix m) {
    m *= scalar;
    return m;
}


matrix operator*(const matrix& a, const matrix& b) {
    if (a.numcols() != b.numrows()) {
        std::cerr << "error: incorrect dimentions for matrix "
                  << "multiplication" << std::endl;
        throw;
    }
    
    int nrows = a.numrows();
    int ncols = b.numcols();
    int n{a.numcols()};
    matrix m{a.GetEpsilon(), nrows, ncols};
    for (int row = 0; row < nrows; row++) {
        for (int col = 0; col < ncols; col++) {
            double s{0};
            for (int i = 0; i < n; i++) {
                s += a[row][i] * b[i][col];
            }
            //m[row][col] = s;
            m[row].set(col, s);
        }
    }
    return m;
}
    


