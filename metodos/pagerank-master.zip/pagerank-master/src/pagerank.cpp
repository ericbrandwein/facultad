#include "pagerank.hpp"

void pagerank_matrix(matrix& w, double p) {
    diagonal_matrix d(w.numcols());

    std::vector<unsigned> degrees(w.numcols(), 0);
    for (unsigned row = 0; row < d.size(); row++)
         w[row].add_degrees(degrees);

    for(unsigned row = 0; row < d.size(); row++) {
        int degree = degrees[row];
        if(degree != 0) {
            d[row] = 1.0/degree;
        } else {
            d[row] = 0;
        }
    }

    // w = -pWD
    w *= d;
    w *= -p;

    // w = I-pWD
    for(int i = 0; i < w.numcols(); i++) {
        w[i].set(i, w[i].get(i) + 1);
    }
}

std::vector<double> pagerank(matrix& w, const double p) {
    pagerank_matrix(w, p);

    // gamma*e = (1,....1)t - suponiendo gamma = 1
    std::vector<double> e(w.numrows(), 1);

    return solve(w, e);
}
