#include "operators-stl.hpp"
#include "matrix.hpp"

matrix::matrix(double epsln, std::ifstream &file):epsilon{epsln} {
    int m;
    std::string line;
    std::istringstream iss;
    std::getline(file, line);
    if (line.length() == 0) {
        std::cerr<<"error: incorrect graph input" << std::endl;
        throw;
    }
    iss = std::istringstream(line);
    iss >> nrows;
    ncols = nrows; // matrix de adyacencias es cuadrada.
    std::getline(file, line);
    if (line.length() == 0) {
        std::cerr<<"error: incorrect graph input" << std::endl;
        throw;
    }
    iss = std::istringstream(line);
    iss >> m;
    // todo: validar n y m
    elem.insert(elem.end(), nrows, //std::vector<double>(ncols));
                vector_ralo{epsilon, ncols});
    int orig, dest, edge = 0;
    for (; std::getline(file, line); edge++) {
        std::istringstream iss(line);
        iss >> orig >> dest;
        orig--; dest--;
        //elem[orig][dest] = elem[dest][orig] = double{1};
        // elem[orig].set(dest, double{1});
        elem[dest].set(orig, double{1});
    }
    if (edge != m) {
        std::cerr << "error: reading from file. "
                  << "Wrong number of edges" << std::endl;
        throw;
    }
}


matrix::matrix(double epsln, std::vector<double> v, int numrows) {
    if (numrows < 0) {
        std::cout << "matrix: nrow can't be negativ" << std::endl;
        throw;
    } else if (v.size() % numrows != 0) {
        std::cout << "matrix: rows must be of same size\n";
        throw;
    }
    nrows = numrows;
    ncols = v.size() / nrows;

    //for (int i = 0; i < nrows; i++) {

    for (int i = 0; i < nrows; i++) {
        elem.push_back(vector_ralo{epsilon, v, i*ncols, (i+1)*ncols});
                // v.begin() + i * ncols,
                // v.begin() + (i+1) * ncols));
    }
}

matrix& matrix::operator+=(const matrix& other) {
    if (nrows != other.numrows() || ncols != other.numcols()) {
        std::cerr << "error: can't sum matrices of diff size\n";
        throw;
    }
    for (int i = 0; i < nrows; i++)
        for (int j = 0; j < ncols; j++) {
            //elem[i][j] += other[i][j];
            elem[i].add(j, other[i][j]);
        }
    return *this;
}


matrix& matrix::operator*=(double scalar) {
    for (auto& v : elem)
        for (auto& x : v)
            x *= scalar;
    return *this;
};


void matrix::substract_times_row(
    int afected, int substracted,const double times) {
    elem[afected].sub_times(elem[substracted], times);
    //for (int i = 0; i < ncols; i++) {
    //elem[afected][i] -= elem[substracted][i] * times;
    // }
}

matrix& matrix::upper_triangular() {
    int pivot_row = 0;
    int row = 0;
    for (int col = 0; row < nrows; col++) {
        while (elem[row].iszero(col) && row < nrows) row++;
        if (row == nrows) { //todos ceros
            row = pivot_row;
        } else {
            if (row > pivot_row)
                std::swap(elem[row], elem[pivot_row]);

            for (int i = pivot_row + 1; i < nrows; i++) {
                if (!elem[i].iszero(col) /*[col] != 0*/) {
                    int afected{i};
                    int substracted{pivot_row};
                    double times{
                        elem[i].get(col)
                            / elem[pivot_row].get(col)};
                    elem[afected]
                        .sub_times(elem[substracted], times);

                //     substract_times_row(
                //         i, pivot_row,
                //         elem[i][col] / elem[pivot_row][col]);
                }
            }
            pivot_row++;
            row++;
        }
    }
    return *this;
}



matrix& matrix::normalize_pivot() {
    for (auto row : elem) {
        int first_col = 0;
        for (int c = first_col; c < ncols; c++) {
            while (c == 0) c++;
            if (c < ncols) {
                first_col = c;
                //row  = row / 2.0;//row[c];
            }
        }
    }
    return *this;
}

matrix& matrix::operator*=(const diagonal_matrix& other) {
    unsigned ncols{static_cast<unsigned>(this->ncols)};
    if (ncols != other.size()) {
        std::cerr << "error: can't multiply matrices\n";
        throw;
    }

    // for(unsigned row = 0; row < this->nrows; row++) {
    //     for(auto it = this->elem[row].begin();
    //         it != this->elem[row].end(); ++it) {
    //         double& e = *it;
    //         e *= other[it.getIndex()];
    //     }
    // }
    unsigned nrows{static_cast<unsigned>(this->nrows)};
    for(unsigned row = 0; row < nrows; row++) {
        for(unsigned col = 0; col < ncols; col++) {
            
            double e = elem[row].get(col);
            e *= other[col];
            elem[row].set(col, e);
        }
    }

    return *this;
}

std::vector<double> matrix::operator*(std::vector<double>& v) {
  std::vector<double> res(v.size());
  for(int fila = 0; fila < static_cast<int>(v.size()); fila++) {
    double acc = 0;

    vector_ralo& fila_actual = this->elem[fila];
    for(auto it_columna = fila_actual.begin_in_map(); it_columna.is_not_map_end(); it_columna.next_in_map()) {
      acc += v[it_columna.getIndex()] * (*it_columna);
    }
    res[fila] = acc;
  }

  return res;
}

// // esta función equivale a usar, una vez validados los índices:
// // std::swap(m[row_i], m[row_j])
// void swap_rows(matrix &m, int row_i, int row_j) {
//      if (row_i < 0 || m.numrows() <= row_i || row_j < 0 || m.numrows() <= row_j) {
//         std::cerr << "error: incorrect numb of row\n";
//         throw;
//     }
//     // porque no std::swap(m[row_i], m[row_j]); ?
//     std::vector<double> temp = m[row_i];
//     m[row_i] = m[row_j];
//     m[row_j] = temp;
// }

void matrix::sum_row_to_all(std::vector<double>& r) {
  for(auto& fila : this->elem) {
    for(auto it_columna = fila.begin(); it_columna != fila.end(); ++it_columna) {
      int i = it_columna.getIndex();
      fila.add(i, r[i]);
    }
  }
}
