#ifndef _VECTOR_RALO_H
#define _VECTOR_RALO_H

#include "epsilon.h"
#include <map>
#include <vector>
#include <math.h>


class vector_ralo {
    double epsilon;
    int sz;
    std::map<int, double> elem;
    friend class iterator;



    double& operator[](int i) {
        if (i < 0 || size() <= i) {
            std::cerr << "vector ralo: index out of range\n";
            throw;
        }
        return elem[i];
    }

public:

    vector_ralo(double epsln, int s=0) : epsilon{epsln}, sz{s}, elem{} {}

    // esto hacerlo con itradores después
    vector_ralo(double epsln, std::vector<double> v, int desde, int hasta)
        : epsilon(epsln), sz{hasta - desde}, elem{}{
        for (int i = 0; i < sz; i++)
            set(i, v[i + desde]);

    }

    double operator[](int i) const {
        if (i < 0 || size() <= i) {
            std::cerr << "vector ralo: index out of range\n";
            throw;
        }
        auto v = elem.find(i);
        if (v == elem.end())
            return 0;
        return double{v->second};
    }

    // double& operator[](int i) {
    //     if (i < 0 || size() <= i) {
    //         std::cerr << "vector ralo: index out of range\n";
    //         throw;
    //     }
    //     return elem[i];
    // }


    vector_ralo& operator*=(double d) {
        for (auto& x : elem)
            x.second *= d;
        return *this;
    }


    bool operator==(vector_ralo& other) {
        return elem == other.elem;
    }



    int size() const { return sz; }
    int nonnulls() const { return elem.size(); }
    void push_back(double d) { elem[sz++] = d; };

    bool iszero(double d) { return fabs(d) < epsilon;/*return d == double{0};*/ }
    bool iszero(int indx) { return iszero(elem[indx]); }


    void set(int indx, const double d) {
        if (iszero(d))
            elem.erase(indx);
        else
            elem[indx] = d;
    }

    double get(int indx) {
        return elem[indx];
    }

    void add(int indx, const double d) {
        set(indx, elem[indx] + d);
    }

    void sub(int indx, const double d) {
        set(indx, elem[indx] - d);
    }


    void sub_times(const vector_ralo& other, double times) {
        for (int i = 0; i < size(); i++) {
            sub(i, other[i] * times);
        }
    }

    void add_degrees(std::vector<unsigned>& v) {
        for (auto it = begin_in_map();
             it.is_not_map_end();
             it=it.next_in_map())

            v[it.getIndex()] += 1;

    }
class iterator {
        vector_ralo* v;
        std::map<int, double>::iterator it;
        int index;
        double zero = 0.0;


    public:

        iterator(vector_ralo * pvec, int indx) {
            v = pvec;
            index = indx;
            it = v->elem.lower_bound(indx);
        }

    
    iterator& next_in_map() {
        it++;
        if (it != v->elem.end()) {
            index = it->first;
        } else {
            index = v->size();
        }
        return *this;
                    
    }

    bool is_not_map_end() {
        return it != v->elem.end(); 
    }
    
    iterator& operator++() {
            //int map_size{static_cast<int>(v->elem.size())};
            bool quedan_en_vector = (index < v->size());

            if (quedan_en_vector) {
                index++;

                bool quedan_en_map = (it != v->elem.end());
                bool index_paso_a_map = index > it->first;
                if (quedan_en_map && index_paso_a_map) {
                    it++;
                }
            }
            return *this;
        };

        const double& operator*() const {
            if (index == it -> first && it != v->elem.end())
                return it -> second;
            return zero;
        }

        double& operator*()  {
            if (index == it -> first && it != v->elem.end())
                return it -> second;
            return zero;
        }

        bool operator==(const iterator& other) {
            return index == other.index
                && *v == *(other.v);
        }
        bool operator!=(const iterator& other) {
            return !(*this == other);
        }
    
        int getIndex() {
            return this->index;
        }
    
    
    };

    iterator begin () {
        return iterator{this, 0};
    }

    iterator begin_in_map () {
        // v = pvec;
        // index = indx;
        // it = v->elem.lower_bound(indx);
        
        // iterator it = iterator{this, 0};
        // if (iszero(*it))
        //     it = it.next_in_map();
        return iterator{this, elem.begin()->first};
    }
    
    iterator end () {
        return iterator{this, size()};
    }

    void log() {
        for (auto x : elem) {
            std::cout << "(" << x.first << " "
                      << x.second << ") ";
        }
        std::cout << std::endl;
    }

    void print() {
        for (int i = 0; i < size(); i++) {
            std::cout << (*this)[i] << " ";
        }
        std::cout << std::endl;
    }

};

// vector_ralo operator* (const vector_ralo& v, double d) {
//     vector_ralo res{v};
//     res *= d;
//     return res;
// }

#endif //_VECTOR_RALO_H
