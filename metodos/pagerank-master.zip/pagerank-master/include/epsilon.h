#ifndef _EPSILON_H
#define _EPSILON_H

extern double EPSILON;

#endif
