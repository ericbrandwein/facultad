#ifndef _OPERATORS_H
#define _OPERATORS_H

#include "matrix.hpp"
//#include "vector-ralo.hpp"
//class vector_ralo;

matrix operator+(matrix a, const matrix& b);
matrix operator*(double scalar, matrix m);
matrix operator*(const matrix& a, const matrix& b) ;

//vector_ralo operator* (const vector_ralo& v, double d) ;


#endif // _H_OPERATORS
