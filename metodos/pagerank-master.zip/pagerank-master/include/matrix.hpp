#ifndef _MATRIX_H
#define _MATRIX_H

#include <set>
#include <stdexcept>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <random>

#include <cstring>

#include "epsilon.h"
#include "operators-stl.hpp"
#include "vector-ralo.hpp"
#include "diagonal-matrix.hpp"

//#define EPSILON 0.00000001

class matrix {
    double epsilon;
    int nrows;
    int ncols;
    //std::vector<std::vector<double>> elem;
    std::vector<vector_ralo> elem;
    // todo: usar una clase fila q sea como vector<double>
    //       pero que tire error en index out of range, no?
public:
    // constructores
    matrix(double epsln, int nfilas, int ncolumnas)
        : epsilon{epsln}, nrows{nfilas}, ncols{ncolumnas} {
            if (nrows < 0 || ncolumnas < 0) {
                std::cerr
                    << "matrix: negatve matrix's dimension.\n";
                throw;
            }
        elem.insert(
            elem.end(), nrows, vector_ralo{epsilon, ncols});
    }
    matrix(double epsln, std::ifstream &file);
    // constructor por copia
    matrix(const matrix& m)
        : epsilon{m.epsilon}, nrows{m.nrows}, ncols{m.ncols},  elem{m.elem} {}
    // constr. por asignacion igual al de copia, no hace falta
    // constructor de vector
    matrix(double epsln, std::vector<double> v, int numrows);

    int numrows() const { return nrows; }
    int numcols() const { return ncols; }

    // operadores
    //std::vector<double>& operator[](int i) {
    vector_ralo& operator[](int i) {
        if (i < 0 || nrows <= i) {
            std::cerr << "matrix: index out of range\n";
            throw;
        }
        return elem[i];
    }

    //const std::vector<double>& operator[](int i) const {
    const vector_ralo& operator[](int i) const {
        if (i < 0 || nrows <= i) {
            std::cerr << "matrix: index out of range\n";
            throw;
        }
        return elem[i];
    }

    matrix& operator+=(const matrix& other);
    matrix& operator*=(const diagonal_matrix& other);
    matrix& operator*=(double scalar);
    std::vector<double> operator*(std::vector<double>& v);

    matrix& upper_triangular();
    matrix& normalize_pivot();

    void sum_row_to_all(std::vector<double>& r);
    //
    void print_square() {
        for (auto v : elem) {
            int i = 0;
            for (auto x : v) {
                std::cout << x;
                if (++i  < ncols)
                    std::cout << " ";
                else
                    std::cout << std::endl;
                // std::setw(10) <<
                //x << " ";
                //<< std::setpreciseion(4) << x << " ";
            }

        }

    }
    double GetEpsilon() const { // std::cout << epsilon << std::endl; 
        return epsilon;
    }
    
private:
    void substract_times_row(int afected, int substracted, double times);
};


#endif // _MATRIX_H
