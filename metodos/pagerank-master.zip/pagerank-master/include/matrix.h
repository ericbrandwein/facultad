#ifndef _MATRIX_HEADERS
#define _MATRIX_HEADERS

#include "matrix.hpp"
#include "operators.hpp"
#include "functions.hpp"


#define ISZERO_EPSILON 1e-3
#endif // _MATRIX_HEADERS
