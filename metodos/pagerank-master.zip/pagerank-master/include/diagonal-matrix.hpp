#ifndef _DIAGONAL_MATRIX_H
#define _DIAGONAL_MATRIX_H

#include <vector>

typedef std::vector<double> diagonal_matrix;

#endif