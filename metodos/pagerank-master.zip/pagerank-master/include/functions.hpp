#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H

#include "matrix.hpp"

matrix transpose(matrix &m) ;
matrix
random_matrix(int numrows, int numcols, double low, double high, double epsilon);


void sum_row_i_times_k_to_row_j(
        matrix &m, int& row_i, double& k, int& row_j, int& desde_que_columna);

matrix gaussian_elimination(matrix &m);
matrix gaussian_elimination_sin_pivoteo(matrix &m);

std::vector<double> solve(matrix &m, std::vector<double> &t);


#endif // _FUNCTIONS_H
