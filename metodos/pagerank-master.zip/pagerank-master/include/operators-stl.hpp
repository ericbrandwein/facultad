#ifndef _OPERATORS_STL_T_
#define _OPERATORS_STL_T_

#include <vector>


std::vector<double>
operator*(double d, const std::vector<double>& v);

std::vector<double>
operator/(const std::vector<double>& v,double d);


#endif // _OPERATORS_STL_T_
