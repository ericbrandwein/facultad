#ifndef _PAGERANK_H
#define _PAGERANK_H

#include <vector>
#include "matrix.hpp"
#include "diagonal-matrix.hpp"
#include "functions.hpp"

void pagerank_matrix(matrix& w, double p);
std::vector<double> pagerank(matrix& w, const double p);

#endif // _PAGERANK_H
