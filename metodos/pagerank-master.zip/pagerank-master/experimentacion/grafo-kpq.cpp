#include <iostream>
#include <string>

void print_usage(const char * cmd) {
    std::cout << "uso: " << cmd << " n [m]"
              << std::endl
              << "n y m son numeros." << std::endl
              << "Si solo n es dado devuelve Kn, si no Knm"
              << std::endl;
}


void print_Kn(int n) {
    
    std::cout << n << std::endl
              << (n * (n-1))
              << std::endl;
    
    for (int i = 1; i <= n; i++) {
        for (int j = i + 1; j <= n; j++) {
            std::cout << i << " " << j << std::endl;
            std::cout << j << " " << i << std::endl;

        }
    }
}

void print_Knm(int p, int q) {
    int n = p + q;
    std::cout << n << std::endl
              << (p * q) * 2
              << std::endl;
    
    for (int i = 1; i <= p; i++) {
        for (int j = p + 1; j <= n; j++) {
            std::cout << i << " " << j << std::endl;
            std::cout << j << " " << i << std::endl;

        }
    }
}

int main (int argc, char ** argv) {
    if (argc == 2) {
        print_Kn(std::stoi(argv[1]));
    } else if (argc == 3) {
        print_Knm(std::stoi(argv[1]),
                  std::stoi(argv[1]));

    } else {
        print_usage(argv[0]);
    } 

    return 0;
}

