
#include <iostream>
#include <string>

void print_usage(const char * cmd) {
    std::cout << "uso: " << cmd << " n"
              << std::endl
              << "n es numero." << std::endl
              << "Escribe estrella (o como se llame) de n nodos en stdout"
              << std::endl;
}


void print_estrella(int n) {
    
    std::cout << n << std::endl
              << (n - 1)
              << std::endl;
    
    for (int i = 2; i <= n; i++) {
            std::cout << i << " " << 1 << std::endl;

    }
}

int main (int argc, char ** argv) {
    if (argc == 2) {
        print_estrella(std::stoi(argv[1]));
    }  else {
        print_usage(argv[0]);
    } 

    return 0;
}

