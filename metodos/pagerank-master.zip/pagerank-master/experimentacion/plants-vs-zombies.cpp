/*
  Este escribe un Kn y una estrella (al vezre) de m.
  La estrella unida al K.
*/
#include <iostream>
#include <string>

void print_usage(const char * cmd) {
    std::cout << "uso: " << cmd << " n [m]"
              << std::endl
              << "n y m numeros. (no pongo el acento porque es ascii)" << std::endl
              << "Escribe Kn y llatre m (si hay m)"
              << std::endl;
}



void print_Kn(int n) {
    
    // std::cout << n << std::endl
    //           << (n * (n-1))
    //           << std::endl;
    
    for (int i = 1; i <= n; i++) {
        for (int j = i + 1; j <= n; j++) {
            std::cout << i << " " << j << std::endl;
            std::cout << j << " " << i << std::endl;

        }
    }
}

void print_llatre(int desde, int hasta) {
    // std::cout << desde - 1 << " " << desde << std::endl
    //           << desde << " " << desde -1 << std::endl;
    
    for (int i = desde + 1; i <= hasta; i++) {
        std::cout << i << " " << desde << std::endl;
    }
}

int main (int argc, char ** argv) {
        

    if (argc == 3) {

        int n = std::stoi(argv[1]);
        int m = std::stoi(argv[2]);
        if (m < 3) {
            std::cerr << "menos de 3 te parece?"
                      << " a mi no, chau"
                      << std::endl;
            exit(1);
        }
        std::cout << n + m << std::endl
                  << (n * (n - 1)) + m 
                  << std::endl;
        print_Kn (n);
        print_llatre(n, n + m);
    }  else {
        print_usage(argv[0]);
    } 

    return 0;
}

