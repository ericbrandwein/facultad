/*
  La idea con este era compararlo con los circuitos
  y ver que el circuito iba a beneficiar al ultimo 
  y este seria igualitario (por la simetria).
*/

#include <iostream>
#include <string>

void print_usage(const char * cmd) {
    std::cout << "uso: " << cmd << " n"
              << std::endl
              << "n es numero." << std::endl
              << "Escribe Pn enn stdout"
              << std::endl;
}


void print_camino(int n) {
    
    std::cout << n << std::endl
              << (n - 1)
              << std::endl;
    
    for (int i = 1; i < n; i++) {
            std::cout << i << " " << i + 1 << std::endl;

    }
}

int main (int argc, char ** argv) {
    if (argc == 2) {
        print_camino(std::stoi(argv[1]));
    }  else {
        print_usage(argv[0]);
    } 

    return 0;
}

