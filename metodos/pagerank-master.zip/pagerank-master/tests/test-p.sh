#!/bin/bash

OUTPUT=tests/resultados/rankings_p

rm -f $OUTPUT

for p in $(LANG=en_US seq 0 0.1 1); do
  echo -n $(./build/tp1 experimentacion/inputs/camino-10 $p) >> $OUTPUT
  echo >> $OUTPUT
done
