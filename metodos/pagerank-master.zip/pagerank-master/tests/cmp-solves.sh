#!/bin/bash

RCMD=./solve-matrix.R
TPCMD=../build/tsolve
for f in $@; do
    printf "R: "
    $RCMD $f
    printf "TP:"
    $TPCMD  $f
    echo
done

