#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=TRUE)

x = read.table(args[1])
b = rep(1, dim(x)[1])
s = solve(x, b)
s = s / sum(s) 
