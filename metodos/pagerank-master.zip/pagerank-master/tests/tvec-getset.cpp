#include <iostream>

#include "vector-ralo.hpp"


const int nfilas = 5;
const int ncols = 9;

int main() {
     // creo martiz en R^filas x ncols
     //matrix m(nfilas, ncols);
     vector_ralo v{10};
     v.print();
     std::cout << v.get(0) << std::endl;
     for (int i = 0; i < 6; i++)
         v.set(i,1e2);
     v.print();
     std::cout << std::endl;

     std::cout << std::endl;

     return 0;
}
