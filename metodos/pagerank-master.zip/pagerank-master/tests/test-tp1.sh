#!/bin/bash

TP_CMD=../build/tp1

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

if [ ! -f $TP_CMD ]; then
    echo Falta compilar $TP_CMD
else
    for f in $(ls -rS data/test_*txt); do
        printf  "[test ${f}] "
        p=$(head -1  ./$f.out)

        DIFF=$( diff -q <($TP_CMD ./$f $p) ./$f.out ) &
        PID=$!
        i=1
        sp="/-\|"
        echo -n ' '
        while [ -d /proc/$PID ]
        do
            printf "\b${sp:i++%${#sp}:1}"
        done
        printf "\b"

        if [ -z "$DIFF" ]; then
            printf  "${GREEN}ok${NC}\n"
        else
            printf "${RED}error${NC}: test failed\n"
        fi

    done
fi
