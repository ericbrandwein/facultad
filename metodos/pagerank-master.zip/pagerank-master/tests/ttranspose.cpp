#include <iostream>

#include "matrix.h"


int main(int argc, char** argv) {
     int filas = 3;
     int columnas = 3;

     matrix a{ISZERO_EPSILON, filas, columnas};

     a[0].set(0, 1);
     a[0].set(1, 1);
     a[0].set(2, 6);

     a[1].set(0, 3);
     a[1].set(1, 0);
     a[1].set(2, 1);

     a[2].set(0, 1);
     a[2].set(1, 1);
     a[2].set(2, 4);

     std::cout << "matrix a" << std::endl;
     a.print_square();
     std::cout << "matrix a * b" << std::endl;
     matrix b{transpose(a)};
     b.print_square();
}
