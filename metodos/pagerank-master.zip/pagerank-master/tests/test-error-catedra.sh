#!/bin/bash

EPSILON_FILE=$1

OUT_RANKING=/tmp/ranking.out
OUT_CATEDRA=/tmp/catedra.out


for file in data/*.txt ; do
  OUTPUT_FILE=resultados/error-catedra-$(basename $file)
  echo "epsilon ranking" > $OUTPUT_FILE

  p=$(head -n 1 ${file}.out)

  while read e; do
    ../build/tp1 $file $p $e | tail -n +1 > $OUT_RANKING
    cat $file.out | tail -n +1 > $OUT_CATEDRA

    error=$(./calcular-error.R $OUT_CATEDRA $OUT_RANKING)

    echo "$e $error" >> $OUTPUT_FILE
  done < $EPSILON_FILE
done
