#include <iostream>

#include "matrix.h"

int main(int argc, char** argv) {
     int nfilas = 9;
     int ncols = 12;

     matrix a{random_matrix(nfilas, ncols,0, 1, ISZERO_EPSILON)};

     std::cout << "matrix a" << std::endl;
     a.print_square();
     std::cout << "matrix a * b" << std::endl;
     a.upper_triangular();
     a.normalize_pivot();
     //std::swap(a[0],a[1]);
     
     std::cout << "--------------" << std::endl;
     a.print_square();
}
