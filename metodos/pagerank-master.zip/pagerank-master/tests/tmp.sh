sleep 7 &
PID=$!
i=1
sp="/-\|"
echo -n ' '
while [ -d /proc/$PID ]
do
    printf "\b${sp:i++%${#sp}:1}"
    sleep 0.1
done
