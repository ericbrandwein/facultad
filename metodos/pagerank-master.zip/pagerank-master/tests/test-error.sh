#!/bin/bash

INPUT_FILE=$1
EPSILON_FILE=$2
OUTPUT_FILE=$3

echo "epsilon error tiempo" > $OUTPUT_FILE

while read e; do
  error=$(./build/medir_error $INPUT_FILE 0.9 $e | awk '{ total += $1; count++ } END { print total/count }')
  tiempo=$({ TIMEFORMAT="%U"; time ./build/tp1 tests/data/test_15_segundos.txt 0.9 $e > /dev/null; } 2>&1)

  echo "$e $error $tiempo" >> $OUTPUT_FILE
done < $EPSILON_FILE

