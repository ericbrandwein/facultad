#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=TRUE)

x = as.matrix(read.table(args[1], header=FALSE, skip=1))
y = as.matrix(read.table(args[2], header=FALSE, skip=1))

error = sum(abs(x-y)) / dim(x)[1]
cat(error, "\n")
