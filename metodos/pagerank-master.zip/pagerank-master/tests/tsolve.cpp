#include <iostream>
#include <sstream>
#include <fstream>

#include "matrix.h"

void open_file(std::ifstream& file, char * filename) {
     file.open(filename);
     if (!file) {
          std::cerr << "No se pudo leer " << filename
                    << std::endl;
          exit(1);
     }
}

int read_file(std::vector<double>& v,std::ifstream& file) {
    std::string line;
    int i = 0;
    int nfilas = 0;
    int ncols = -1;
    while (getline(file, line)) {
        std::istringstream iss(line);
        double d;
        while (iss >> d) {
            i++;
            v.push_back(d);
        }
        if (ncols < 0) ncols = i;
        nfilas++;
    }
    if (i % nfilas != 0) {
        std::cerr << "error: esta mal el nro de filas\n";
        exit(1);
    }
        
    file.close();
    return nfilas;
}

int main(int argc, char** argv) {
     if (argc < 2 ) {
          std::cout << "file missing" << std::endl;
     } else {
          std::ifstream file;
          char* filename = argv[1];
          open_file(file, filename);
          std::vector<double> v;
          int nrows = read_file(v, file);
          matrix m{ISZERO_EPSILON, v, nrows};
          file.close();
          std::vector<double> b(nrows, double{1});
          auto solu = solve(m, b);
          for (auto x : solu)
               std::cout << std::setprecision(10)
                         << x << " ";
          std::cout << std::endl;
              
          return 0;
     }
}
