#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=TRUE)

D.foo = function(W) {
    rows = sapply(colSums(W),
         function(x) if(x == 0) { 0 } else { 1/x })
    diag(rows)
}

W = as.matrix(read.table(args[1]))
D = D.foo(W)
p = as.numeric(args[2])
n = dim(W)[1]
b = rep(1, n)

s = solve (diag(n) - p * W%*%D, b)
s = s / sum(s)
cat(paste(s, collapse="\n"), "\n")
