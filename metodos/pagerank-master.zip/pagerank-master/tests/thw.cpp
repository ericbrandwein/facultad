#include <iostream>

#include "matrix.h"


const int nfilas = 5;
const int ncols = 9;


int main() {
     // creo martiz en R^filas x ncols
    matrix m(ISZERO_EPSILON, nfilas, ncols);
     
     m.print_square();
     int c = 0;
     for (int i = 0; i < nfilas; i++)
          for (int j = 0; j < ncols; j++)
              m[i].set(j, double(c++)/10);
     
     std::cout << std::endl;
     m.print_square();
     std::cout << std::endl;

     return 0;
}
