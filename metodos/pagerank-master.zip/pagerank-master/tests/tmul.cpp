#include <iostream>

#include "matrix.h"

void open_file(std::ifstream& file, char * filename) {
     file.open(filename);
     if (!file) {
          std::cerr << "No se pudo leer " << filename
                    << std::endl;
          exit(1);
     }
}


int main(int argc, char** argv) {
     if (argc < 2 ) {
          std::cout << "file missing" << std::endl;
     } else {
          std::ifstream file;
          char* filename = argv[1];
          open_file(file, filename);
          matrix a(ISZERO_EPSILON,file);
          file.close();
          //matrix c = a + b;
          a *= 1.7;
          a.print_square();
          std::cout << std::endl;
          return 0;
     }
}
