#!/bin/bash

RCMD=./solve-matrix.R
TPCMD=../build/tsolve
for f in $@; do
    DIFF=$(diff -q <($RCMD $f) <($TPCMD  $f))
    if [ ! -z  "$DIFF" ]; then
        echo error $DIFF
    fi
done

