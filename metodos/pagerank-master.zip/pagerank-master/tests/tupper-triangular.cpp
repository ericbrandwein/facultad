#include <iostream>

#include "matrix.h"

int main(int argc, char** argv) {
     int nfilas = 9;
     int ncols = 12;

     matrix a{random_matrix(nfilas, ncols,0, 1, ISZERO_EPSILON)};

     // matrix a{filas, columnas};
     // a[0][0] = 0;
     // a[0][1] = 1;
     // a[0][2] = 6;

     // a[1][0] = 3;
     // a[1][1] = 0;
     // a[1][2] = 1;

     // a[2][0] = 1;
     // a[2][1] = 1;
     // a[2][0] = 4;
     std::cout << "matrix a" << std::endl;
     a.print_square();
     std::cout << "matrix a * b" << std::endl;
     a.upper_triangular();
     //std::swap(a[0],a[1]);
     std::cout << "--------------" << std::endl;
     a.print_square();
}
