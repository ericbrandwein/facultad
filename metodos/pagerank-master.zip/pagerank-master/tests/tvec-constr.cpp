#include <iostream>

#include "matrix.h"

const int nfilas = 5;
const int ncols = 9;

int main() {
     // creo martiz en R^filas x ncols

     matrix a(ISZERO_EPSILON, std::vector<double>{
               1.1, 2.9,1.3,7.4,5.01,6.23,7.11,1.8,4.9}, 3);
     a.print_square();
     std::cout << std::endl;
     matrix b(ISZERO_EPSILON, std::vector<double>{0,1,2,3,4,5,6,7,8,9}, 2);
     b.print_square();
     std::cout << std::endl;
     matrix c(ISZERO_EPSILON, std::vector<double>{0,1,2,3,4,5,6,7,8,9}, 5);
     c.print_square();
     std::cout << std::endl;
     
     return 0;
}
