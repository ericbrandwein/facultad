#include <iostream>

#include "matrix.h"


int main(int argc, char** argv) {
     int a = 3;
     int b = 3;
     int c = 1;
     matrix ma{ISZERO_EPSILON, a, b};
     matrix mb{ISZERO_EPSILON, b, c}; 

     ma[0].set(0, 1);
     ma[0].set(1, 1);
     ma[0].set(2, 6);

     ma[1].set(0, 3);
     ma[1].set(1, 0);
     ma[1].set(2, 1);

     ma[2].set(0, 1);
     ma[2].set(1, 1);
     ma[2].set(2, 4);

     mb[0].set(0, 2);
     mb[1].set(0, 5);
     mb[2].set(0, 0);

     std::cout << "matrix a" << std::endl;
     ma.print_square();
     std::cout << "matrix b" << std::endl;
     mb.print_square();
     matrix mc{ma * mb};
     std::cout << "matrix a * b" << std::endl;
     mc.print_square();
     

}
