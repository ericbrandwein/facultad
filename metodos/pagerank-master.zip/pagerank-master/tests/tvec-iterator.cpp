#include <iostream>

#include "vector-ralo.hpp"


const int nfilas = 5;
const int ncols = 9;
const double iszero_epsilon_vector {1e-3};

int main() {
     // creo martiz en R^filas x ncols
     //matrix m(nfilas, ncols);
    vector_ralo v{iszero_epsilon_vector,19};
    vector_ralo w{iszero_epsilon_vector};
     for (int i = 0; i < 16; i++)
         v.set(i,1e2);

     v.set(9, 0.5);
     v.set(6, 0.6);
     v.set(0, 1.1);
     
     v.log();
     int i = 0;
     for (auto it = v.begin(); it != v.end(); ++it) {
         std::cout << i++ << ": " << *it << std::endl;
         if (i > 777) {
             std::cerr << "error en != end()";
             break;

         }
     }

     std::cout << std::endl;
          
     return 0;
}
