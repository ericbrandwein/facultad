#!/bin/bash

for i in {2..20}
do
    ../build/trand-matrix $i $i > matrices/m${i}_${i}
done
