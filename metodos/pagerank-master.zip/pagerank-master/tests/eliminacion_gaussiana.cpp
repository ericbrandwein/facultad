#include <iostream>

#include "matrix.h"

int main() {

    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    std::cout<<"Case rows = columns :\n"<<std::endl;
    matrix m0 = random_matrix(6, 6, -10, 10, ISZERO_EPSILON);
    m0.print_square(); std::cout<<" "<<std::endl;
    gaussian_elimination_sin_pivoteo(m0);
    m0.print_square();

    std::cout << "------------------------------------------" << std::endl;

    std::cout<<"Case rows > columns :\n"<<std::endl;
    matrix m1 = random_matrix(7, 5, -10, 10, ISZERO_EPSILON);
    m1.print_square(); std::cout<<" "<<std::endl;
    gaussian_elimination_sin_pivoteo(m1);
    m1.print_square();

    std::cout << "------------------------------------------" << std::endl;

    std::cout<<"Case rows < columns :\n"<<std::endl;
    matrix m2 = random_matrix(5, 7, -10, 10, ISZERO_EPSILON);
    m2.print_square(); std::cout<<" "<<std::endl;
    gaussian_elimination_sin_pivoteo(m2);
    m2.print_square();

    return 0;
}
