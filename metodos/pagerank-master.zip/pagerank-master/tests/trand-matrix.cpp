#include <iostream>
#include <sstream>

#include "matrix.h"

const int nfilas = 9;
const int ncols = 11;

int main(int argc, char** argv) {
    if (argc != 3) {
        std::cout << "uso: " << argv[0] << " Nfilas Ncols\n";
        exit(0);
    }
    int nfilas, ncols;
    std::istringstream nfilas_stream(argv[1]);
    std::istringstream ncols_stream(argv[2]);        
    if (! (nfilas_stream >> nfilas)) {
        std::cerr << "número invalido: '" << argv[1]
                   << std::endl;
        exit(1);
    }

    if (! (ncols_stream >> ncols)) {
        std::cerr << "número invalido: '" << argv[2]
                   << std::endl;
        exit(1);
    }

    matrix a{random_matrix(ISZERO_EPSILON, nfilas, ncols,0, 1)};
    a.print_square();
    return 0;
}
