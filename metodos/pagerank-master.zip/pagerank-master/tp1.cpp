#include <iostream>
#include <stdlib.h>

#include "matrix.h"
#include "vector-ralo.hpp"
#include "functions.hpp"
#include "pagerank.hpp"

double EPSILON = 1e-3;

void open_file(std::ifstream& file, char * filename) {
     file.open(filename);
     if (!file) {
          std::cerr << "No se pudo leer " << filename
                    << std::endl;
          exit(1);
     }
}


void print(const double p, const std::vector<double> pr) {
    std::cout << p << std::endl;
    for(auto x : pr) {
        std::cout << x << std::endl;
    }
}

int main(int argc, char** argv) {
     if (argc < 3 ) {
          std::cout << "Arguments missing, archivo p" << std::endl;
     } else {
          std::ifstream file;
          char* filename = argv[1];
          double p = atof(argv[2]);

          if(argc == 4) {
            double e = atof(argv[3]);
            EPSILON = e;
          }

          open_file(file, filename);
          matrix w(EPSILON, file);
          file.close();

          std::vector<double> pr = pagerank(w, p);
          print(p, pr);

          return 0;
     }
}
