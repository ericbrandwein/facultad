library(ggplot2)
library(dplyr)
library(readr)
library(stringr)
library(tidyr)

PATH = "../tests/resultados/"

datos <- read.table(paste(PATH, "error-catedra-test_15_segundos.txt", sep=""), header = TRUE)
datos %>% 
  ggplot(aes(x = epsilon, y = ranking)) + 
  geom_line() +
  labs(x = "Epsilon", y = "error")
ggsave("15s_epsilon_error_catedra.png")

datos_promedio <- read.table(paste(PATH, "error-catedra-test_30_segundos.txt", sep=""), header = TRUE)
datos_max <- read.table(paste(PATH, "error-catedra-max-test_30_segundos.txt", sep=""), header = TRUE)
datos <- cbind(datos_promedio)
datos['ranking'] <- NULL
datos['error_promedio'] <- datos_promedio['ranking']
datos['error_max'] <- datos_max['error']
datos

datos %>% 
  ggplot(aes(x = epsilon)) + 
  geom_line(aes(y=error_promedio, colour="promedio")) +
  geom_line(aes(y=error_max, colour = "maximo")) +
  labs(x = "Epsilon", y = "Error", colour="Tipo de Error")
ggsave("30s_epsilon_error_catedra_promedio_vs_max.png")

datos_promedio <- read.table(paste(PATH, "error-catedra-test_15_segundos.txt", sep=""), header = TRUE)
datos_max <- read.table(paste(PATH, "error-catedra-max-test_15_segundos.txt", sep=""), header = TRUE)
datos <- cbind(datos_promedio)
datos['ranking'] <- NULL
datos['error_promedio'] <- datos_promedio['ranking']
datos['error_max'] <- datos_max['error']
datos

datos %>% 
  ggplot(aes(x = epsilon)) + 
  geom_line(aes(y=error_promedio, colour="promedio")) +
  geom_line(aes(y=error_max, colour = "maximo")) +
  labs(x = "Epsilon", y = "Error", colour="Tipo de Error")
ggsave("15s_epsilon_error_catedra_promedio_vs_max.png")


datos %>% 
  ggplot(aes(x = epsilon, y = error)) + 
  geom_line() +
  labs(x = "Epsilon", y = "error")
#ggsave("15s_epsilon_error_max_catedra.png")

datos <- read.table(paste(PATH, "error-catedra-test_aleatorio.txt", sep=""), header = TRUE)
datos %>% 
  ggplot(aes(x = epsilon, y = ranking)) + 
  geom_line() +
  labs(x = "Epsilon", y = "error")
ggsave("aleatorio_epsilon_error_catedra.png")

datos <- read.table(paste(PATH, "error-catedra-max-test_15_segundos.txt", sep=""), header = TRUE)
datos %>% 
  ggplot(aes(x = epsilon, y = error)) + 
  geom_line() +
  labs(x = "Epsilon", y = "error")
#ggsave("15s_epsilon_error_max_catedra.png")




