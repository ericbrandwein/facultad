library(ggplot2)
library(dplyr)
library(readr)
library(stringr)
library(tidyr)

PATH = "../tests/resultados/"
datos <- read.table("../tests/resultados/rankings_p", header = TRUE)
