library(ggplot2)
library(dplyr)
library(readr)
library(stringr)
library(tidyr)

PATH = "../tests/resultados/"

datos <- read.table(paste(PATH, "errores_15s", sep=""), header = TRUE)
datos %>% 
  ggplot(aes(x = epsilon, y = error)) + 
  geom_line() +
  labs(x = "Epsilon", y = "error")
ggsave("15s_error_solucion.png")

datos %>% 
  ggplot(aes(epsilon, log(tiempo))) + 
  geom_line() +
  labs(x = "Epsilon", y = "tiempo (segundos)")
ggsave("15s_epsilon_tiempo.png")

datos <- read.table(paste(PATH, "errores_30s", sep=""), header = TRUE)
datos %>% 
  ggplot(aes(x = epsilon, y = error)) + 
  geom_line() +
  labs(x = "Epsilon", y = "error")
ggsave("30s_error_solucion.png")

datos %>% 
  ggplot(aes(x = epsilon, y = tiempo)) + 
  geom_line() +
  labs(x = "Epsilon", y = "tiempo (segundos)")
ggsave("30s_epsilon_tiempo.png")
