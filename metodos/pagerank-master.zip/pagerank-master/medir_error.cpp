#include <iostream>
#include <cmath>
#include <stdlib.h>

#include "matrix.h"
#include "vector-ralo.hpp"
#include "functions.hpp"
#include "pagerank.hpp"

double EPSILON = 1e-3;

void open_file(std::ifstream& file, char * filename) {
     file.open(filename);
     if (!file) {
          std::cerr << "No se pudo leer " << filename
                    << std::endl;
          exit(1);
     }
}

std::vector<double> pagerank_error(matrix& w, const double p) {
    matrix a(w);

    std::vector<double> pr = pagerank(w, p);

    //
    diagonal_matrix d(w.numcols());

    std::vector<unsigned> degrees(w.numcols(), 0);
    for (unsigned row = 0; row < d.size(); row++)
         a[row].add_degrees(degrees);

    for(unsigned row = 0; row < d.size(); row++) {
        int degree = degrees[row];
        if(degree != 0) {
            d[row] = 1.0/degree;
        } else {
            d[row] = 0;
        }
    }

    // a = pWD
    a *= d;
    a *= p;

    // como e = (1, ... 1) entonces e * z = la matriz de todas filas z
    std::vector<double> z(a.numrows(), 0);
    for(int i = 0; i < z.size(); i++) {
      if(d[i] != 0) {
        z[i] = (1-p) / a.numrows();
      } else {
        z[i] = 1.0 / a.numrows();
      }
    }

    a.sum_row_to_all(z);

    std::vector<double> error = a * pr;

    for(int i = 0; i < error.size(); i++) {
      error[i] = fabs(error[i] - pr[i]);
    }

    return error;
}

void print(const double p, const std::vector<double> pr) {
    std::cout << p << std::endl;
    for(auto x : pr) {
        std::cout << x << std::endl;
    }
}

int main(int argc, char** argv) {
     if (argc < 3 ) {
          std::cout << "Arguments missing, archivo p" << std::endl;
     } else {
          std::ifstream file;
          char* filename = argv[1];
          double p = atof(argv[2]);

          if(argc == 4) {
            double e = atof(argv[3]);
            EPSILON = e;
          }

          open_file(file, filename);
          matrix w(file);
          file.close();

          std::vector<double> pr = pagerank_error(w, p);
          print(p, pr);

          return 0;
     }
}
